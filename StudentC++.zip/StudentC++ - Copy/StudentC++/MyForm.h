#pragma once
#include"MyForm1.h"

namespace StudentC {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	public ref class MyForm : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlcon = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
		MySqlDataReader^ sqlRD;
		DataSet^ DS = gcnew DataSet();

		String^ sqlQuary;
		String^ server = "localhost";
		String^ username = "root";
		String^ password = "screenshot";
	private: System::Windows::Forms::Button^ button3;

	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label1;
		   String^ database = "cppstudentdb";

	public:
		MyForm(void)
		{
			InitializeComponent();
		}

	protected:
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Panel^ panel1;

	private: System::Windows::Forms::DataGridView^ dataGridView1;
	protected:

	private:
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::LightBlue;
			this->button1->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button1->Location = System::Drawing::Point(784, 627);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(101, 42);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Add New Student";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(200)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(200)));
			this->panel1->Controls->Add(this->dataGridView1);
			this->panel1->Location = System::Drawing::Point(12, 12);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(1346, 583);
			this->panel1->TabIndex = 1;
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToOrderColumns = true;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(0, 0);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(1343, 580);
			this->dataGridView1->TabIndex = 0;
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::LightBlue;
			this->button3->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button3->Location = System::Drawing::Point(665, 627);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(101, 42);
			this->button3->TabIndex = 0;
			this->button3->Text = L"Delete";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox1->Location = System::Drawing::Point(477, 634);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(166, 30);
			this->textBox1->TabIndex = 1;
			this->textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::textBox1_KeyPress);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(602, 651);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(41, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Search";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::PaleGreen;
			this->ClientSize = System::Drawing::Size(1370, 687);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->textBox1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"MyForm";
			this->Text = L"Varendra University";
			this->Load += gcnew System::EventHandler(this, &MyForm::loadfrom);
			this->panel1->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void dataUpload()
	{
		sqlcon->ConnectionString = "server=" + server + ";" + "username=" + username + ";"
			"password=" + password + ";" + "database =" + database;
		sqlcon->Open();
		sqlCmd->Connection = sqlcon;
		sqlCmd->CommandText = "SELECT * FROM cppstudentdb.mydata;";
		sqlRD = sqlCmd->ExecuteReader();
		sqlDt->Load(sqlRD);
		sqlRD->Close();
		sqlcon->Close();
		dataGridView1->DataSource = sqlDt;
	}
	
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Hide();
		MyForm1^ from = gcnew MyForm1(this);
		from->ShowDialog();

	}

	private: System::Void loadfrom(System::Object^ sender, System::EventArgs^ e) {
		dataUpload();
	}

	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
		System::Windows::Forms::DialogResult iAdd;
		iAdd = MessageBox::Show("Conferm If You wnat to Add this Student",
			"Varandra Univercity Student Management System", MessageBoxButtons::YesNo, MessageBoxIcon::Question);

		if (iAdd == System::Windows::Forms::DialogResult::Yes)
		{
			try
			{
				sqlcon->ConnectionString = "server=" + server + ";" + "username=" + username + ";"
					"password=" + password + ";" + "database =" + database;
				sqlcon->Open();
				sqlCmd->Connection = sqlcon;
				sqlCmd->CommandText = "DELETE FROM cppstudentdb.mydata WHERE Name = " + textBox1->Text;//DataGridViewSelectionMode.FullRowSelect;
				sqlRD = sqlCmd->ExecuteReader();
				sqlDt->Load(sqlRD);

			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
			finally {
				sqlRD->Close();
				sqlcon->Close();
			}
		}

	
	}
	private: System::Void textBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		try
		{
			if (e->KeyChar == (Char)13)
			{
				DataView^ dv = sqlDt->DefaultView;
				dv->RowFilter = String::Format("ID like '%{0}%'", textBox1->Text);
				dataGridView1->DataSource = dv->ToTable();
			}
		}
		catch (Exception^ ex)
		{
			MessageBox::Show(ex->Message);
		}
	}
};
}
